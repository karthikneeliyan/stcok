import React, { Component } from "react";


class Main extends Component {
    constructor(props) {
      super(props);
    }
render()
{
    return(<h1>test</h1>);
}

}

export default Main;