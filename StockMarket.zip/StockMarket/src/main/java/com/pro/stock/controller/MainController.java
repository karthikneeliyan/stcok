package com.pro.stock.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pro.stock.service.impl.ChartServiceImpl;

@CrossOrigin("*")
@RestController
public class MainController {
	@Autowired
	ChartServiceImpl chartServiceImpl;

	@GetMapping("/daily")
	public ArrayList<HashMap<String, Object>> getDailyData() throws JsonMappingException, JsonProcessingException {
		final String uri = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=MSFT&outputsize=full&apikey=demo";

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, List> map = mapper.readValue(result, HashMap.class);
		System.out.println(result);
		System.out.println(map);
		LinkedHashMap<Object, Object> al = (LinkedHashMap<Object, Object>) map.get("Time Series (Daily)");
		System.out.println(al);
		ArrayList<HashMap<String, Object>> resultList = chartServiceImpl.getHighchartData(al,"yyyy-MM-dd");
		Collections.reverse(resultList);
		return resultList;

	}

	@GetMapping("/weekly")
	public ArrayList<HashMap<String, Object>> getWeeklyData() throws JsonMappingException, JsonProcessingException {
		final String uri = "https://www.alphavantage.co/query?function=TIME_SERIES_WEEKLY_ADJUSTED&symbol=MSFT&apikey=demo";

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String, List> map = mapper.readValue(result, HashMap.class);
		System.out.println(result);
		System.out.println(map);
		LinkedHashMap<Object, Object> al = (LinkedHashMap<Object, Object>) map.get("Weekly Adjusted Time Series");
		System.out.println(al);
		ArrayList<HashMap<String, Object>> resultList = chartServiceImpl.getHighchartData(al, "yyyy-MM-dd");

		return resultList;

	}

}
