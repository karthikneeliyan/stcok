package com.pro.stock.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.pro.stock.service.ChartService;
@Service
public class ChartServiceImpl implements ChartService{

	@Override
	public ArrayList<HashMap<String,Object>> getHighchartData(LinkedHashMap<Object, Object> al,String dateFormat) {
		
		LinkedHashMap<Object, Object> hm=new LinkedHashMap<>();
		ArrayList<HashMap<String,Object>> resultList=new ArrayList<HashMap<String,Object>>();
		 Date date = null;
		Set<Object> keys = al.keySet();
        for(Object k:keys){
        	  SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

              try {

            	  date = formatter.parse((String) k);

              } catch (ParseException e) {
                  e.printStackTrace();
              }
        	  HashMap lhm=(HashMap) al.get(k);
        	 HashMap map=new HashMap<>();
        	 map.put("high", lhm.get("2. high"));
        	 map.put("low", lhm.get("3. low"));
        	 map.put("open", lhm.get("1. open"));
        	 map.put("close", lhm.get("4. close"));
        	 map.put("volume", lhm.get("5. volume"));
        	 map.put("date", date);
        	 resultList.add(map);
        }
		return resultList;
	}

	

}
