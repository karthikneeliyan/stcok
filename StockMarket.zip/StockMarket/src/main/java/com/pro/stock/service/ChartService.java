package com.pro.stock.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

public interface ChartService {
	
	public ArrayList<HashMap<String,Object>> getHighchartData(LinkedHashMap<Object,Object> al,String dateFormat);
	

}
